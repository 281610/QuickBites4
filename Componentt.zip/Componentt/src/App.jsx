import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import About from './Components/About'
import { div } from 'framer-motion/client'
import AboutUs from './Components/AboutUs'
import ContactUs from './Components/Contactus'
import Cart from './Components/Cart'

function App() {

return(
  <div>

    {/* <About /> */}
    {/* <AboutUs /> */}
{/* <ContactUs />
 */}
 <Cart />
    </div>
)
    
     
}

export default App
